# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.admin.views.decorators import staff_member_required
from django.urls import reverse
from .models import Course, Student, StudentCourse

# ------------------------------------------------------------------------------
# DASHBOARD VIEW
# ------------------------------------------------------------------------------
@staff_member_required
def admin_dashboard(request):
    """
    Renders the custom admin dashboard containing an overview of courses
    and student enrollments.
    """
    # For example, show total courses and total student-course enrollments
    courses_count = Course.objects.count()
    enrollments_count = StudentCourse.objects.count()
    context = {
        'courses_count': courses_count,
        'enrollments_count': enrollments_count
    }
    
    return render(request, 'admin/dashboard.html', context)


# ------------------------------------------------------------------------------
# COURSE MANAGEMENT VIEWS
# ------------------------------------------------------------------------------
@staff_member_required
def course_list_view(request):
    """
    Displays a list of all available courses.
    """
    courses = Course.objects.all()
    return render(request, 'admin/course_list.html', {'courses': courses})


@staff_member_required
def course_detail_view(request, pk):
    """
    Displays details for a specific course.
    """
    course = get_object_or_404(Course, pk=pk)
    # Include related information if required (like professor, classroom, etc.)
    return render(request, 'admin/course_detail.html', {'course': course})


@staff_member_required
def add_course_view(request):
    """
    Provides a form to add a new course.
    If method is POST, validates and saves the course.
    """
    if request.method == 'POST':
        # Assume form fields are sent in POST; adjust field names according to your model.
        course_name = request.POST.get('course_name')
        course_code = request.POST.get('course_code')
        exam_time = request.POST.get('exam_time')
        capacity = request.POST.get('capacity')
        # Additional fields: department, professor, classroom, class_date, class_time, etc.
        
        # Validation can be added here
        if course_name and course_code and capacity:
            # Create and save the course instance
            course = Course(
                course_name=course_name,
                course_code=course_code,
                exam_time=exam_time,
                capacity=capacity,
                remaining_capacity=capacity  # Initially all spots available
            )
            # Here you would also set foreign keys such as department, professor, etc.
            course.save()
            
            # Redirect to the course list or course detail page
            return redirect(reverse('course_list_view'))
        else:
            # If invalid, you might want to show an error message in the template.
            context = {'error': "لطفا همه فیلدهای ضروری را پر کنید."}
            return render(request, 'admin/add_course.html', context)
    
    # GET request renders the empty form
    return render(request, 'admin/add_course.html')


@staff_member_required
def edit_course_view(request, pk):
    """
    Provides a form to update the details of an existing course.
    """
    course = get_object_or_404(Course, pk=pk)
    
    if request.method == 'POST':
        # Update course attributes based on POST data
        course.course_name = request.POST.get('course_name', course.course_name)
        course.course_code = request.POST.get('course_code', course.course_code)
        course.exam_time = request.POST.get('exam_time', course.exam_time)
        capacity = request.POST.get('capacity')
        if capacity:
            # If capacity is updated, also update the remaining capacity accordingly.
            # This is a simplified example. A more robust implementation may check
            # for already enrolled students.
            course.capacity = capacity
            course.remaining_capacity = capacity
        # Update additional attributes if necessary 
        
        course.save()
        return redirect(reverse('course_detail_view', args=[course.pk]))
    
    return render(request, 'admin/edit_course.html', {'course': course})


# ------------------------------------------------------------------------------
# STUDENT COURSE SELECTION MANAGEMENT
# ------------------------------------------------------------------------------
@staff_member_required
def course_selection_view(request):
    """
    Displays a page where an admin can assign students to courses.
    Lists available courses and students.
    """
    courses = Course.objects.all()
    students = Student.objects.all()
    
    context = {
        'courses': courses,
        'students': students
    }
    return render(request, 'admin/course_selection.html', context)


@staff_member_required
def course_selection_save_view(request):
    """
    Processes the form submission to enroll selected students in selected courses.
    """
    if request.method == 'POST':
        # Expect POST to contain 'courses' and 'students' as lists of selected IDs.
        selected_course_ids = request.POST.getlist('courses')
        selected_student_ids = request.POST.getlist('students')
        
        for course in Course.objects.filter(pk__in=selected_course_ids):
            for student in Student.objects.filter(pk__in=selected_student_ids):
                # Create the enrollment only if it does not already exist
                StudentCourse.objects.get_or_create(student=student, course=course)
                # Optionally, you might update course.remaining_capacity in the model's save() method.
        
        # Redirect to a success page which you would create (or back to course list)
        return redirect(reverse('course_selection_view'))
    
    # If GET, simply render the selection form.
    return render(request, 'admin/course_selection.html')


@staff_member_required
def course_selection_delete_view(request):
    """
    Processes the deletion of course enrollments for given courses and students.
    """
    if request.method == 'POST':
        selected_course_ids = request.POST.getlist('courses')
        selected_student_ids = request.POST.getlist('students')
        
        # Filter enrollments matching the selected students and courses. 
        StudentCourse.objects.filter(course__pk__in=selected_course_ids,
                                     student__pk__in=selected_student_ids).delete()
        
        # Redirect after deletion to an appropriate page.
        return redirect(reverse('course_selection_view'))
    
    return render(request, 'admin/course_selection.html')
