from django.apps import AppConfig


class AppcoursewareConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appCourseWare'

