from django.urls import path
from . import views, adminViews

urlpatterns = [
    # USER
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('create-student-profile/', views.create_student_profile, name='create_student_profile'),

    # ADMIN PANEL
    path('admin/dashboard/', adminViews.admin_dashboard, name='admin_dashboard'),
    path('admin/course_list/', adminViews.course_list_view, name='course_list_view'),
    path('admin/course/<int:pk>/', adminViews.course_detail_view, name='course_detail_view'),
    path('admin/course/add/', adminViews.add_course_view, name='add_course_view'),
    path('admin/course/edit/<int:pk>/', adminViews.edit_course_view, name='edit_course_view'),
    path('admin/course_selection/', adminViews.course_selection_view, name='course_selection_view'),
    path('admin/course_selection/save/', adminViews.course_selection_save_view, name='course_selection_save_view'),
    path('admin/course_selection/delete/', adminViews.course_selection_delete_view, name='course_selection_delete_view'),
]